from setuptools import find_packages, setup

setup(
    name="Dshell-Training-Pack",
    version="0.1",
    author="USArmyResearchLab",
    description="A collection of Dshell plugins used for training purposes",
    url="https://github.com/USArmyResearchLab/Dshell",
    python_requires='>=3.5',
    packages=find_packages(),
    install_requires=[
        "Dshell",
    ],
    entry_points={
        "dshell_plugins": [
            "example  = dshell_training.example",
            "test_    = dshell_training.test",
            "testhttp = dshell_training.testhttp",
        ],
    }
)
