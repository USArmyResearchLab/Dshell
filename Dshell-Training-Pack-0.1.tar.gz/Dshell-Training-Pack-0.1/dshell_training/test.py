import dshell.core
import dshell.output.alertout

class DshellPlugin(dshell.core.PacketPlugin):

    def __init__(self):
        super().__init__(
            name="test",
            output=dshell.output.alertout.AlertOutput(label=__name__),
        )

    def packet_handler(self, packet):
        self.write(**packet.info())
        return packet
