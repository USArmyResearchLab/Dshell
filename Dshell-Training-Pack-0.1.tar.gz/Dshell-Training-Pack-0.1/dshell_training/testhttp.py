import dshell.core
from dshell.plugins.httpplugin import HTTPPlugin
from dshell.output.alertout import AlertOutput

class DshellPlugin(HTTPPlugin):
    def __init__(self):
        super().__init__(
            name="Example HTTP",
            bpf="tcp and (port 80 or port 8080 or port 8000)",
            output=AlertOutput(label=__name__)
        )

    def http_handler(self, conn, request, response):
        requested_item = "{} {}/{}".format(request.method, request.headers['host'], request.uri)
        self.write(requested_item, **conn.info())
        return conn, request, response
