import dshell.core
from dshell.output.alertout import AlertOutput

class DshellPlugin(dshell.core.ConnectionPlugin):
    def __init__(self):
        super().__init__(
            name="test tcp",
            bpf="tcp",
            description="Counts the number of times '.com' appears in a connection",
            longdescription="Counts the number of times '.com' appears in a connection using most of the functions available to Dshell",
            author="user",
            output=AlertOutput(label=__name__),
            optiondict={
                "show_zeroes": {
                    "action": "store_true",
                    "help": "Show connections without '.com'",
                    "default": False
                }
            }
        )

    def premodule(self):
        self.conn_com_instances = {}
        self.total_instances_of_com = 0

    def postmodule(self):
        self.debug(".com seen {} times".format(self.total_instances_of_com))

    def connection_init_handler(self, conn):
        # Initialize a counter for this connection that will hold the number
        # of times .com appears
        self.conn_com_instances[conn] = 0

    def blob_handler(self, conn, blob):
        # Checks the blob's data for '.com'
        c = blob.data.lower().count(b'.com')
        try:
            self.conn_com_instances[conn] += c
            return conn, blob
        except KeyError:
            return

    def connection_handler(self, conn):
        # Prints the .com count
        # Only return connections that match the conditional
        try:
            if self.show_zeroes or self.conn_com_instances[conn] > 0:
                msg = ".com count: {}".format(self.conn_com_instances[conn])
                self.write(msg, **conn.info())
                return conn
        except KeyError:
            return

    def connection_close_handler(self, conn):
        # Remove the connection from the counter cache
        try:
            self.total_instances_of_com += self.conn_com_instances[conn]
            del self.conn_com_instances[conn]
        except KeyError:
            pass
